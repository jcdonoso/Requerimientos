package controller;

import model.ListDepartamento;
import model.ListGerencia;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import model.ListUsuario;
import model.Requerimiento;

@WebServlet(name = "Gerencia", urlPatterns = {"/Gerencia"})
public class Gerencia extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int valor = Integer.parseInt(request.getParameter("comboGerencia"));
        int valord = Integer.parseInt(request.getParameter("comboDepartamento"));
        int valordas = Integer.parseInt(request.getParameter("comboDepartamentoAs"));
        int valoru = Integer.parseInt(request.getParameter("Usuario"));
      
        String comentarios = request.getParameter("comentarios");
        int estado = 1;
        
        Requerimiento req = new Requerimiento();
        req.guardar(comentarios, estado, valoru, valord, valordas, valor);
        request.getRequestDispatcher("menuPrincipal.jsp").forward(request, response);
        
      
        
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

//                String l = request.getParameter();
     
        String valor = request.getParameter("comboGerencia");
        String valord = request.getParameter("comboDepartamento");
        String valordas = request.getParameter("comboDepartamentoAs");
        String valoru = request.getParameter("Usuario");
        String comentarios = request.getParameter("comentarios");

        request.setAttribute("valor", valor);
        request.setAttribute("valord", valord);
        request.setAttribute("valordas", valordas);
        request.setAttribute("valorus", valoru);
        
        
        ListGerencia list = new ListGerencia();

        ArrayList<ListGerencia> List = (ArrayList<ListGerencia>) list.listar();
        request.setAttribute("lista", List);

        if (valor != null) {
            ListDepartamento listdep = new ListDepartamento();
            listdep.setIdGerencia(Integer.parseInt(valor));
            ArrayList<ListDepartamento> ListDep = (ArrayList<ListDepartamento>) listdep.listar();
            request.setAttribute("listadep", ListDep);
        }
        ListDepartamento listd = new ListDepartamento();
        ArrayList<ListDepartamento> Listd = (ArrayList<ListDepartamento>) listd.listarda();
        request.setAttribute("listarda", Listd);
        
        if(valordas!=null){
            ListUsuario listusu = new ListUsuario();
            listusu.setIdDepartamento(Integer.parseInt(valordas));
            ArrayList<ListUsuario> listus = (ArrayList<ListUsuario>) listusu.listaru();
            request.setAttribute("listau", listus);
       }
        
        
        request.getRequestDispatcher("ingresarRequerimiento.jsp").forward(request, response);

    }
}
