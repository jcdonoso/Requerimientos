package controller;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexion {

    private static String url = "jdbc:mysql://localhost:3306/requerimiento";
    private Connection con;

    public Conexion() {
        // Cargamos el driver de mysql
        try {
            Class.forName("com.mysql.jdbc.Driver");
            // Creamos el objeto conexion
            con = DriverManager.getConnection(url, "root","root");

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


   public Connection getConexion(){
    return con;
    }

//    public static void main(String[] args) {
//        Conexion co = new Conexion();
//
//
//    }
}
