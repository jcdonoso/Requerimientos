
package model;

import controller.Conexion;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class Requerimiento extends Conexion {
    
    private int idRequerimiento;
    private String descripcion;
    private boolean estado;
    private int rut;
    private int idDepartamentoSolicita;
    private int idDepartamentoASignado;
    private int idGerencia;

    public int getIdRequerimiento() {
        return idRequerimiento;
    }



    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public int getRut() {
        return rut;
    }

    public void setRut(int rut) {
        this.rut = rut;
    }

    public int getIdDepartamentoSolicita() {
        return idDepartamentoSolicita;
    }

    public void setIdDepartamentoSolicita(int idDepartamentoSolicita) {
        this.idDepartamentoSolicita = idDepartamentoSolicita;
    }

    public int getIdDepartamentoASignado() {
        return idDepartamentoASignado;
    }

    public void setIdDepartamentoASignado(int idDepartamentoASignado) {
        this.idDepartamentoASignado = idDepartamentoASignado;
    }

    public int getIdGerencia() {
        return idGerencia;
    }

    public void setIdGerencia(int idGerencia) {
        this.idGerencia = idGerencia;
    }
     
    
    public boolean guardar(String descripcion,int estado, int rut, int idDepartamentoSolicita,int idDepartamentoAsigna, int idGerencia ){
    
        PreparedStatement ps = null;


        try {

            String consulta ="insert into  requerimiento (descripcion,estado,rut,idDepartamentoSolicita,idDepartamentoASignado,idGerencia) values (?,?,?,?,?,?)";

            ps = getConexion().prepareStatement(consulta);
            ps.setString(1,descripcion);
            ps.setInt(2,estado);
            ps.setInt(3,rut);
            ps.setInt(4,idDepartamentoSolicita);
            ps.setInt(5,idDepartamentoAsigna);
            ps.setInt(6,idGerencia);
            if (ps.executeUpdate()==1){
                return true;
            }
        }catch (Exception e){
            System.err.println("error"+e);
        }
        finally {

            try {
                if (getConexion()!=null) { getConexion().close();}
                if (ps != null){ps.close();}

            } catch (SQLException e) {
                System.err.println("error"+e);
            }

        }

        return false;
    }
    
        public static void main(String[] args) {
        Requerimiento l = new Requerimiento();

        l.guardar("descripcion", 1, 1, 1, 1, 1);

    }
    
    }

