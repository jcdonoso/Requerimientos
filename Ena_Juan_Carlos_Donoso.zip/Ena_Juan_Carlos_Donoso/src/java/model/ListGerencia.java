package model;

import controller.Conexion;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ListGerencia extends Conexion {

    private String tipo;
    private int id;

    public ListGerencia() {
    }

    public ListGerencia(String tipo, int id) {
        this.tipo = tipo;
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<ListGerencia> listar() {

        ArrayList<ListGerencia> list = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {

            String consulta = "select * from gerencia";

            ps = getConexion().prepareStatement(consulta);
            rs = ps.executeQuery();


            while (rs.next()) {
                ListGerencia user = new ListGerencia();
                user.setId(rs.getInt("idGerencia"));
                user.setTipo(rs.getString("descripcion"));
                list.add(user);
            }

        } catch (Exception e) {
            System.err.println("error" + e);
        } finally {

            try {
                if (getConexion() != null) {
                    getConexion().close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                System.err.println("error" + e);
            }

            return list;

        }

    }

    public static void main(String[] args) {
        ListGerencia l = new ListGerencia();

        for (ListGerencia u:l.listar()
             ) {
            System.out.println(u.getTipo());
            System.out.println(u.getId());
        }

    }

}