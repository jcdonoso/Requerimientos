package model;

import controller.Conexion;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ListDepartamento extends Conexion {
    private int id;
    private String descripcion;
    private int idGerencia;

    public ListDepartamento() {
    }

    public ListDepartamento(int id, String descripcion, int idGerencia) {
        this.id = id;
        this.descripcion = descripcion;
        this.idGerencia = idGerencia;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getIdGerencia() {
        return idGerencia;
    }

    public void setIdGerencia(int idGerencia) {
        this.idGerencia = idGerencia;
    }


    public List<ListDepartamento> listar() {

        ArrayList<ListDepartamento> list = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {

            String consulta = "select * from departamento where idGerencia = ?";

            ps = getConexion().prepareStatement(consulta);
            ps.setInt(1, idGerencia);
            rs = ps.executeQuery();


            while (rs.next()) {
                ListDepartamento user = new ListDepartamento();
                user.setId(rs.getInt("idDepartamento"));
                user.setDescripcion(rs.getString("descripcion"));
                user.setIdGerencia(rs.getInt("idGerencia"));
                list.add(user);
            }

        } catch (Exception e) {
            System.err.println("error" + e);
        } finally {

            try {
                if (getConexion() != null) {
                    getConexion().close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                System.err.println("error" + e);
            }

            return list;

        }

    }

    public List<ListDepartamento> listarda() {

        ArrayList<ListDepartamento> list = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {

            String consulta = "select * from departamento ";

            ps = getConexion().prepareStatement(consulta);
                       rs = ps.executeQuery();
            while (rs.next()) {
                ListDepartamento user = new ListDepartamento();
                user.setId(rs.getInt("idDepartamento"));
                user.setDescripcion(rs.getString("descripcion"));
                user.setIdGerencia(rs.getInt("idGerencia"));
                list.add(user);
            }

        } catch (Exception e) {
            System.err.println("error" + e);
        } finally {

            try {
                if (getConexion() != null) {
                    getConexion().close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                System.err.println("error" + e);
            }

            return list;

        }

    }
//    public static void main(String[] args) {
//        ListDepartamento l = new ListDepartamento();
//
//        for (ListDepartamento u:l.listar()
//        ) {
//            System.out.println(u.getDescripcion());
//            System.out.println(u.getIdGerencia());
//        }
//
//    }

}
