
package model;

import controller.Conexion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ListUsuario extends Conexion{

    private int rut;
    private String nombre;
    private String apellidos;
    private String nombreUsuario;
    private String password;
    private int idDepartamento ;

    public int getRut() {
        return rut;
    }

    public void setRut(int rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getIdDepartamento() {
        return idDepartamento;
    }

    public void setIdDepartamento(int idDepartamento) {
        this.idDepartamento = idDepartamento;
    }

    public List<ListUsuario> listaru() {

        ArrayList<ListUsuario> list = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        try {
           
           String consulta = "select * from usuario where idDepartamento = ? ";
            ps = getConexion().prepareStatement(consulta);
            ps.setInt(1,idDepartamento);
            rs = ps.executeQuery();
            while (rs.next()) {
                ListUsuario usuario = new ListUsuario();
                usuario.setRut(rs.getInt("rut"));
                usuario.setNombre(rs.getString("nombre"));
                usuario.setApellidos(rs.getString("apellidos"));
                usuario.setNombreUsuario(rs.getString("nombreUsuario"));
                usuario.setPassword(rs.getString("password"));
                usuario.setIdDepartamento(rs.getInt("idDepartamento"));
               
                list.add(usuario);
            }
        } catch (Exception e) {
            System.err.println("error" + e);
        } finally {

            try {
                if (getConexion() != null) {
                    getConexion().close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException e) {
                System.err.println("error" + e);
            }

            return list;

        }

    }
    
     public static void main(String[] args) {
        ListUsuario l = new ListUsuario();

        for (ListUsuario u:l.listaru()
        ) {
            System.out.println(u.getRut());
            System.out.println(u.getNombre());
        }

    }
    

}
